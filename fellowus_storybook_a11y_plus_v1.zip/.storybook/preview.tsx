import type { Preview } from '@storybook/react';
import React, { useEffect } from 'react';
import '../src/styles/globals.css';
import '../src/styles/tokens.css';

const withTheme = (Story, context) => {
  const theme = context.globals.theme || 'light';
  useEffect(() => { document.documentElement.setAttribute('data-theme', theme); }, [theme]);
  return <div style={{ background: 'var(--muted-50)', minHeight: '100vh', padding: 16 }}><Story /></div>;
};

const preview: Preview = {
  decorators: [withTheme],
  globalTypes: {
    theme: {
      name: 'Theme',
      description: 'Global theme for components',
      defaultValue: 'light',
      toolbar: {
        icon: 'circlehollow',
        items: [
          { value: 'light', title: 'Light' },
          { value: 'dark', title: 'Dark' },
        ],
      },
    },
  },
};
export default preview;
