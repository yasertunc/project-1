import React from 'react';
export const ReportBubble: React.FC<{ onClick?: ()=>void }> = ({ onClick }) => (
  <div className="sticky top-2 ml-auto flex items-center gap-2 rounded-pill bg-white px-3 py-1 text-xs shadow cursor-pointer select-none"
       onClick={onClick}
       title="Raporla">
    <span aria-hidden>⚠️</span>
    <span>Raporla</span>
  </div>
);
