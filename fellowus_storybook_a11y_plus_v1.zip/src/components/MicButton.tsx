import React from 'react';
export const MicButton: React.FC<{ recording?: boolean; onPress?: ()=>void; onRelease?: ()=>void }>
= ({ recording=false, onPress, onRelease }) => {
  return (
    <button
      aria-pressed={recording}
      onMouseDown={onPress}
      onMouseUp={onRelease}
      onTouchStart={onPress}
      onTouchEnd={onRelease}
      className={`rounded-pill px-3 py-2 inline-flex items-center gap-2 ${recording ? 'bg-danger-500 text-white' : 'bg-muted-100 text-ink-700 hover:bg-muted-50'}`}
    >
      <span aria-hidden>🎤</span>
      <span>{recording ? 'Kaydediliyor… basılı tut' : 'Sesli komut'}</span>
    </button>
  );
};
