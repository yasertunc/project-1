import type { Meta, StoryObj } from '@storybook/react';
import { SuggestionCard } from '../components/SuggestionCard';

const meta: Meta<typeof SuggestionCard> = { title: 'Fellowus/SuggestionCard', component: SuggestionCard };
export default meta;
type Story = StoryObj<typeof SuggestionCard>;

export const Guide: Story = {
  args: { title: '#oyun odasında 2 kişi bekliyor', meta: 'Sakin sohbet önerisi', primaryCta: { label: 'Katıl' }, secondaryCta: { label: 'Gizle' } }
};
export const Warning: Story = {
  args: { title: 'Kişisel bilgi paylaşma', tone: 'warning', secondaryCta: { label: 'Kuralları gör' } }
};
