# Fellowus – Event Contracts v1
Tarih: 2025-11-10T10:04:32.534818Z

Bu paket, Matching Acceptance Flow için **JSON Schema** sözleşmelerini ve **Reason/Code** sözlüklerini içerir.

## İçerik
- `schemas/common.json` – ortak alanlar
- `schemas/*.schema.json` – event bazlı şemalar
- `dictionaries/*.json|*.csv` – sabit sözlükler

## Kullanım
- Üretim öncesi doğrulama: JSON Schema validator (AJV, djv, etc.)
- Sürümleme: `eventVersion` alanını minör/majör kurallarıyla güncelleyin.
- Gizlilik: PII yok, `geoHash` hassasiyeti sınırlı, katılımcılar anonim handle.

