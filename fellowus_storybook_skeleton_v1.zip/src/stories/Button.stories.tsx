import type { Meta, StoryObj } from '@storybook/react';
import { Button } from '../components/Button';

const meta: Meta<typeof Button> = {
  title: 'Fellowus/Button',
  component: Button,
  argTypes: { variant: { control: 'select', options: ['primary','outline','ghost','secondary','accent'] } },
};
export default meta;
type Story = StoryObj<typeof Button>;

export const Primary: Story = { args: { children: 'Primary', variant: 'primary' } };
export const Accent: Story = { args: { children: 'EŞLEŞTİR', variant: 'accent' } };
export const Outline: Story = { args: { children: 'Outline', variant: 'outline' } };
