import type { Meta, StoryObj } from '@storybook/react';
import { Chip } from '../components/Chip';

const meta: Meta<typeof Chip> = {
  title: 'Fellowus/Chip',
  component: Chip,
  argTypes: { selected: { control: 'boolean' } },
};
export default meta;
type Story = StoryObj<typeof Chip>;

export const Default: Story = { args: { children: '#müzik', selected: false } };
export const Selected: Story = { args: { children: '#günlük', selected: true } };
