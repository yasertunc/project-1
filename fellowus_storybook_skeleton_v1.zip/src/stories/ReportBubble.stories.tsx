import type { Meta, StoryObj } from '@storybook/react';
import { ReportBubble } from '../components/ReportBubble';

const meta: Meta<typeof ReportBubble> = {
  title: 'Fellowus/ReportBubble',
  component: ReportBubble,
};
export default meta;
type Story = StoryObj<typeof ReportBubble>;

export const Sticky: Story = { render: () => (
  <div style={{ height: 200, overflow: 'auto', border: '1px solid #eee', padding: 8 }}>
    <div style={{ height: 300 }}>
      <ReportBubble onClick={()=>alert('Rapor akışı açıldı')} />
    </div>
  </div>
) };
