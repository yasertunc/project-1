import type { Meta, StoryObj } from '@storybook/react';
import { ChatBubble } from '../components/ChatBubble';

const meta: Meta<typeof ChatBubble> = {
  title: 'Fellowus/ChatBubble',
  component: ChatBubble,
  args: { children: 'Merhaba! 👋' }
};
export default meta;
type Story = StoryObj<typeof ChatBubble>;

export const Inbound: Story = { args: { author: 'other' } };
export const Outbound: Story = { args: { author: 'me' } };
export const System: Story = { args: { author: 'system', children: 'Kişisel bilgi paylaşma.' } };
